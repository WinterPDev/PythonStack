from flask import Flask
app = Flask(__name__)


@app.route('/')
def hello_world():
    return 'Hello World!' 

@app.errorhandler(404)
def page_not_found(e):
    return str('Sorry No Response. Try Again.')

@app.route('/dojo')
def dojo():
    return str('Dojo!')

@app.route('/say/<name>')
def flask(name):
    print(name)
    return str('Hello, ' + name)

@app.route('/repeat/<number>/<word>')
def repeat(number, word):
    return str(word + '\n') * int(number)

if __name__=="__main__": 
    app.run(debug=True)